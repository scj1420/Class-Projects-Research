import dataaccess.DatabaseTest;

public class TestDriver {

    public static void main(String[] args) {
        org.junit.runner.JUnitCore.main(
                "dataaccess.DatabaseTest",
                "dataaccess.AuthTokenDaoTest",
                "dataaccess.EventDaoTest",
                "dataaccess.PersonDaoTest",
                "dataaccess.UserDaoTest");

    }
}