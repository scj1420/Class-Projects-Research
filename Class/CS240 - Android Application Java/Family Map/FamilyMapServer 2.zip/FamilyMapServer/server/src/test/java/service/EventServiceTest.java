package service;

import junit.framework.TestCase;

/**
 * Created by Seong-EunCho on 3/10/17.
 */
public class EventServiceTest extends TestCase {
    public void setUp() throws Exception {
        super.setUp();

    }

    public void testEvent() throws Exception {

    }

    public void testEvent1() throws Exception {

    }

}