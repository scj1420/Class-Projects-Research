package dataaccess;

import junit.framework.TestCase;

import model.User;
import result.LoginResult;

/**
 * Created by Seong-EunCho on 3/3/17.
 */
public class UserDaoTest extends TestCase {
    private UserDao ud;

    public void setUp() throws Exception {
        super.setUp();
        ud = new UserDao();
    }

    public void testInsert() throws Exception {
        User u = new User("scj14", "ko-ng3513", "scj1420@gmail.com", "Seong", "Cho", "m", "123456");
        assertEquals(true, ud.insert(u));
    }

    public void testUpdate() throws Exception {

    }

    public void testDelete() throws Exception {

    }

    public void testLogin() throws Exception {
        LoginResult result = ud.login("scj14", "ko-n3513");
        if (result.isSuccess()){
            System.out.println(result.getSrb().toString());
        } else System.out.println(result.getErb().getMessage());

    }

    public void testFind() throws Exception {
        User u = ud.find("scj14");
        System.out.println(u.toString());
    }

    public void testFindUser() throws Exception{
        System.out.println(ud.findUser("08561784-e293-41e1-bd18-30596c0242e3"));
    }

}