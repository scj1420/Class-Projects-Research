package coder;

import junit.framework.TestCase;

/**
 * Created by Seong-EunCho on 3/9/17.
 */
public class EncoderTest extends TestCase {
    public void setUp() throws Exception {
        super.setUp();

    }

    public void testEncode() throws Exception {

    }

}