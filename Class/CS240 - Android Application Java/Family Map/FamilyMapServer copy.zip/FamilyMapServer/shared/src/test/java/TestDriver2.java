/**
 * Created by Seong-EunCho on 3/10/17.
 */

public class TestDriver2 {
    public static void main(String[] args) {
        org.junit.runner.JUnitCore.main("proxy.ServerProxyTest");

    }
}
