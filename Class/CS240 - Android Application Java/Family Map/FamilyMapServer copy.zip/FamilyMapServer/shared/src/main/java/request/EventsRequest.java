package request;

/**
 * Created by Seong-EunCho on 2/17/17.
 */

/**
 * Information for event(all) method
 *
 * Domain:
 * authToken    : unique auth token
 */
public class EventsRequest {

    /**
     * Creates a EventsRequest object
     *
     * @param authToken
     */
    public EventsRequest(String authToken){}
}
