package dataaccess;

import junit.framework.TestCase;

import result.EventResult;
import result.EventsResult;

/**
 * Created by Seong-EunCho on 3/8/17.
 */
public class EventDaoTest extends TestCase {
    private EventDao ed;

    public void setUp() throws Exception {
        super.setUp();
        ed = new EventDao();
    }

    public void testInsert() throws Exception {
        EventResult result = ed.find("70b828b8-352f-4049-b4b0-b7ac11f6b99d");
        if (result.isSuccess()){
            System.out.println(result.getSrb().toString());
        } else {
            System.out.println(result.getErb().toString());
        }
    }

    public void testUpdate() throws Exception {

    }

    public void testDelete() throws Exception {
        ed.delete("scj14");
    }

    public void testFind() throws Exception {

    }

    public void testRetrieve() throws Exception {
        EventsResult result = ed.retrieve("scj14");
        System.out.println(result.toString());
    }
}