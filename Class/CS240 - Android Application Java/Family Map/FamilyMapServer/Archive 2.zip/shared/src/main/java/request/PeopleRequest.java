package request;

/**
 * Created by Seong-EunCho on 2/17/17.
 */

/**
 * Information for person(all) method
 *
 * Domain:
 * authToken    : unique auth token
 */
public class PeopleRequest {

    /**
     * Creates a PeopleRequest object
     *
     * @param authToken
     */
    public PeopleRequest(String authToken){}
}
