package proxy;

import junit.framework.TestCase;

/**
 * Created by Seong-EunCho on 3/10/17.
 */
public class ServerProxyTest extends TestCase {
    public void setUp() throws Exception {
        super.setUp();

    }

    public void testRegister() throws Exception {

    }

    public void testPerson() throws Exception {

    }

    public void testPerson1() throws Exception {

    }

    public void testLogin() throws Exception {

    }

    public void testLoad() throws Exception {

    }

    public void testFill() throws Exception {

    }

    public void testFill1() throws Exception {

    }

    public void testEvent() throws Exception {

    }

    public void testEvent1() throws Exception {

    }

    public void testClear() throws Exception {

    }

}