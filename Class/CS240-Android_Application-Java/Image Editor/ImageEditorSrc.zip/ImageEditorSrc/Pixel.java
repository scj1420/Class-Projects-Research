/**
 * Created by Seong-EunCho on 1/16/17.
 */

public class Pixel {
    public int red;
    public int green;
    public int blue;
}
